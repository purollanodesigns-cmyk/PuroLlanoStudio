﻿namespace PuroLlanoRadio.Scheduler.Programs;

public class ProgramSlot
{
    public Guid Id { get; set; }

    public DateTime StartTime { get; set; }

    public DateTime EndTime { get; set; }

    public string[] DaysOfWeek { get; set; } = Array.Empty<string>();

    public int Priority { get; set; }
}
