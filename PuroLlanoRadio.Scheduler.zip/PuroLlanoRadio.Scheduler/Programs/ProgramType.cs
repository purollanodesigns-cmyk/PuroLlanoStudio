﻿namespace PuroLlanoRadio.Scheduler.Programs;

public enum ProgramType
{
    Music,
    Live,
    News,
    Commercial,
    Special,
    Recording,
    VoiceTrack
}
