﻿using PuroLlanoRadio.Scheduler.Interfaces;

namespace PuroLlanoRadio.Scheduler.Programs;

public class ProgramManager : IProgramManager
{
    private readonly List<RadioProgram> _programs = new();

    public Task<List<RadioProgram>> GetActiveProgramsAsync(DateTime time)
    {
        var active = _programs.Where(p => p.Slots.Any(s =>
            time >= s.StartTime && time <= s.EndTime)).ToList();

        return Task.FromResult(active);
    }

    public Task<RadioProgram?> GetCurrentProgramAsync()
    {
        var now = DateTime.Now.TimeOfDay;
        var today = DateTime.Today;
        var program = _programs.FirstOrDefault(p => p.Slots.Any(s =>
            now >= s.StartTime.TimeOfDay && now <= s.EndTime.TimeOfDay));

        return Task.FromResult(program);
    }

    public Task RegisterProgramAsync(RadioProgram program)
    {
        _programs.Add(program);
        return Task.CompletedTask;
    }
}
