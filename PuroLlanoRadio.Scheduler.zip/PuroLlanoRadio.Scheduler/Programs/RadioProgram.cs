﻿namespace PuroLlanoRadio.Scheduler.Programs;

public class RadioProgram
{
    public Guid Id { get; set; }

    public string Name { get; set; } = "";

    public string Description { get; set; } = "";

    public ProgramType Type { get; set; }

    public List<ProgramSlot> Slots { get; set; } = new();

    public bool IsActive { get; set; } = true;

    public int Priority { get; set; }
}
