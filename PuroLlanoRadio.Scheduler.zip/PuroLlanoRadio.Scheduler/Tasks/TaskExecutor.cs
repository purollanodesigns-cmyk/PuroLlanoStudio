﻿using PuroLlanoRadio.Scheduler.Interfaces;
using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Tasks;

public class TaskExecutor : ITaskExecutor
{
    public Task<TaskResult> ExecuteAsync(SchedulerTask task)
    {
        var result = new TaskResult
        {
            TaskId = task.Id,
            Success = true,
            ExecutedAt = DateTime.UtcNow
        };

        return Task.FromResult(result);
    }
}
