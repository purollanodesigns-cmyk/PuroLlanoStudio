﻿namespace PuroLlanoRadio.Scheduler.Tasks;

public class TaskResult
{
    public Guid TaskId { get; set; }

    public bool Success { get; set; }

    public string? ErrorMessage { get; set; }

    public DateTime ExecutedAt { get; set; }
}
