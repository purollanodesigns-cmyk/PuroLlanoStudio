﻿namespace PuroLlanoRadio.Scheduler.Tasks;

public class SchedulerTask
{
    public Guid Id { get; set; }

    public string Name { get; set; } = "";

    public DateTime CreatedAt { get; set; }

    public DateTime? ExecutedAt { get; set; }

    public string ActionType { get; set; } = "";

    public Dictionary<string, object> Parameters { get; set; } = new();

    public int Priority { get; set; }
}
