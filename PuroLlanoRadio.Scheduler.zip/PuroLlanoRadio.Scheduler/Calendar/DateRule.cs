﻿namespace PuroLlanoRadio.Scheduler.Calendar;

public class DateRule
{
    public Guid Id { get; set; }

    public string Name { get; set; } = "";

    public DateTime Date { get; set; }

    public bool IsHoliday { get; set; }

    public string Season { get; set; } = "";

    public string OverrideSchedule { get; set; } = "";
}
