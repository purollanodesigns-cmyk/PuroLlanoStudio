﻿using PuroLlanoRadio.Scheduler.Interfaces;

namespace PuroLlanoRadio.Scheduler.Calendar;

public class CalendarProvider : ICalendarProvider
{
    private readonly List<DateRule> _dateRules = new();

    public void AddDateRule(DateRule rule)
    {
        _dateRules.Add(rule);
    }

    public Task<List<DateRule>> GetDateRulesAsync(DateTime from, DateTime to)
    {
        var rules = _dateRules.Where(r =>
            r.Date >= from && r.Date <= to).ToList();

        return Task.FromResult(rules);
    }

    public Task<bool> IsSpecialDateAsync(DateTime date)
    {
        var isSpecial = _dateRules.Any(r => r.Date.Date == date.Date);
        return Task.FromResult(isSpecial);
    }
}
