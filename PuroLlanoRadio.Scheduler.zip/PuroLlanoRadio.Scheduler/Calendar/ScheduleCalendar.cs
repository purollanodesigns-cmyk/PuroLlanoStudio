﻿using PuroLlanoRadio.Scheduler.Events;
using PuroLlanoRadio.Scheduler.Programs;

namespace PuroLlanoRadio.Scheduler.Calendar;

public class ScheduleCalendar
{
    public List<RadioProgram> Programs { get; set; } = new();

    public List<ScheduledEvent> Events { get; set; } = new();

    public List<DateRule> DateRules { get; set; } = new();
}
