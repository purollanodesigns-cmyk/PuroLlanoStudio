﻿using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Actions;

public class StartLiveAction
{
    public string ActionType => "StartLive";

    public async Task<bool> ExecuteAsync(SchedulerTask task)
    {
        return await Task.FromResult(true);
    }
}
