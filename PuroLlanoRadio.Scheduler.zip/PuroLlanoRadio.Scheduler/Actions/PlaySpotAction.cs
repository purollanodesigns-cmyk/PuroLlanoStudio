﻿using PuroLlanoRadio.Mixer.Interfaces;
using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Actions;

public class PlaySpotAction
{
    private readonly IMixerEngine _mixer;

    public string ActionType => "PlaySpot";

    public PlaySpotAction(IMixerEngine mixer)
    {
        _mixer = mixer;
    }

    public async Task<bool> ExecuteAsync(SchedulerTask task)
    {
        await _mixer.StartAsync();
        return true;
    }
}
