﻿using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Actions;

public class PlayMusicAction
{
    private readonly IAutoDjEngine _autoDj;

    public string ActionType => "PlayMusic";

    public PlayMusicAction(IAutoDjEngine autoDj)
    {
        _autoDj = autoDj;
    }

    public async Task<bool> ExecuteAsync(SchedulerTask task)
    {
        await _autoDj.StartAsync();
        return true;
    }
}
