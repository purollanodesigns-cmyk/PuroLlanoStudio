﻿using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Actions;

public class StartRecordingAction
{
    public string ActionType => "StartRecording";

    public async Task<bool> ExecuteAsync(SchedulerTask task)
    {
        return await Task.FromResult(true);
    }
}
