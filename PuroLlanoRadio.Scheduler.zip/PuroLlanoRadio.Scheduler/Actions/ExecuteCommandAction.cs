﻿using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Actions;

public class ExecuteCommandAction
{
    public string ActionType => "ExecuteCommand";

    public async Task<bool> ExecuteAsync(SchedulerTask task)
    {
        var command = task.Parameters.GetValueOrDefault("command")?.ToString() ?? "";
        return await Task.FromResult(true);
    }
}
