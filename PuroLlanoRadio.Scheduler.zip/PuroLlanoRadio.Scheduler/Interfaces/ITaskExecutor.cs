﻿using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Interfaces;

public interface ITaskExecutor
{
    Task<TaskResult> ExecuteAsync(SchedulerTask task);
}
