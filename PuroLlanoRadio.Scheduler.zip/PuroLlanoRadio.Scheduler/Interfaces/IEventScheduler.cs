﻿using PuroLlanoRadio.Scheduler.Events;

namespace PuroLlanoRadio.Scheduler.Interfaces;

public interface IEventScheduler
{
    Task RegisterEventAsync(ScheduledEvent scheduledEvent);

    Task UnregisterEventAsync(Guid eventId);

    Task<List<ScheduledEvent>> GetDueEventsAsync(DateTime time);

    Task<bool> IsEventDueAsync(Guid eventId, DateTime time);
}
