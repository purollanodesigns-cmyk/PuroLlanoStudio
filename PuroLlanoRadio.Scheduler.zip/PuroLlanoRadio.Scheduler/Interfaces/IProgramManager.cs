﻿using PuroLlanoRadio.Scheduler.Programs;

namespace PuroLlanoRadio.Scheduler.Interfaces;

public interface IProgramManager
{
    Task<List<RadioProgram>> GetActiveProgramsAsync(DateTime time);

    Task<RadioProgram?> GetCurrentProgramAsync();

    Task RegisterProgramAsync(RadioProgram program);
}
