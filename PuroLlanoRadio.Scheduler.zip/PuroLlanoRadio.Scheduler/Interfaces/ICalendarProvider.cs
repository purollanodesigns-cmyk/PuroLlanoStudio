﻿using PuroLlanoRadio.Scheduler.Calendar;

namespace PuroLlanoRadio.Scheduler.Interfaces;

public interface ICalendarProvider
{
    Task<List<DateRule>> GetDateRulesAsync(DateTime from, DateTime to);

    Task<bool> IsSpecialDateAsync(DateTime date);
}
