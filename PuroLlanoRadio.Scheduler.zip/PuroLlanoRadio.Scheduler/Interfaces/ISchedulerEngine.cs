﻿namespace PuroLlanoRadio.Scheduler.Interfaces;

public interface ISchedulerEngine
{
    Task StartAsync();

    Task StopAsync();

    Task ExecutePendingEventsAsync();

    bool IsRunning { get; }
}
