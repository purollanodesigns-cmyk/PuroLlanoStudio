﻿namespace PuroLlanoRadio.Scheduler.Events;

public enum EventTrigger
{
    ExactTime,
    Interval,
    Date,
    DayOfWeek,
    Manual
}
