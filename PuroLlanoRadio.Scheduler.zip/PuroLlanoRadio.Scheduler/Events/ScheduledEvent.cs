﻿namespace PuroLlanoRadio.Scheduler.Events;

public class ScheduledEvent
{
    public Guid Id { get; set; }

    public string Name { get; set; } = "";

    public DateTime ScheduledTime { get; set; }

    public EventType Type { get; set; }

    public EventTrigger Trigger { get; set; }

    public bool IsExecuted { get; set; }

    public string ActionType { get; set; } = "";
}
