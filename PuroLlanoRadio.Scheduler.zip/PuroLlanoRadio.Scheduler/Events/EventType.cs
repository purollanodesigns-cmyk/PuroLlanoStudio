﻿namespace PuroLlanoRadio.Scheduler.Events;

public enum EventType
{
    ProgramStart,
    ProgramEnd,
    Commercial,
    Jingle,
    News,
    Recording,
    Live,
    Custom
}
