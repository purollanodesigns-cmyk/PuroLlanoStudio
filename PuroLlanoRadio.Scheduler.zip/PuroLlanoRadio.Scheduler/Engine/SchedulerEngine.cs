﻿using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.Scheduler.Events;
using PuroLlanoRadio.Scheduler.Interfaces;

namespace PuroLlanoRadio.Scheduler.Engine;

public class SchedulerEngine : ISchedulerEngine
{
    private readonly IEventScheduler _eventScheduler;
    private readonly ITaskExecutor _taskExecutor;

    public SchedulerEngine(
        IEventScheduler eventScheduler,
        ITaskExecutor taskExecutor)
    {
        _eventScheduler = eventScheduler;
        _taskExecutor = taskExecutor;
    }

    public Task StartAsync()
    {
        return Task.CompletedTask;
    }

    public Task StopAsync()
    {
        return Task.CompletedTask;
    }

    public Task ExecutePendingEventsAsync()
    {
        return Task.CompletedTask;
    }

    public bool IsRunning { get; private set; }
}
