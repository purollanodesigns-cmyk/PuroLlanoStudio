﻿namespace PuroLlanoRadio.Scheduler.Engine;

public sealed class SchedulerContext
{
    public SchedulerState State { get; set; }

    public int ActivePrograms { get; set; }

    public int PendingEvents { get; set; }

    public int ExecutedTasks { get; set; }

    public DateTime NextEventTime { get; set; }
}
