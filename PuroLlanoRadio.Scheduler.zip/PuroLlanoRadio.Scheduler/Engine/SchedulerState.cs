﻿namespace PuroLlanoRadio.Scheduler.Engine;

public enum SchedulerState
{
    Stopped,
    Loading,
    Running,
    Executing,
    Error
}
