﻿using Microsoft.Extensions.DependencyInjection;
using PuroLlanoRadio.Scheduler.Engine;
using PuroLlanoRadio.Scheduler.Interfaces;
using PuroLlanoRadio.Scheduler.Programs;
using PuroLlanoRadio.Scheduler.Tasks;

namespace PuroLlanoRadio.Scheduler.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddScheduler(
        this IServiceCollection services)
    {
        services.AddSingleton<ISchedulerEngine, SchedulerEngine>();
        services.AddSingleton<IProgramManager, ProgramManager>();
        services.AddSingleton<ITaskExecutor, TaskExecutor>();
        services.AddSingleton<Calendar.CalendarProvider>();

        return services;
    }
}
