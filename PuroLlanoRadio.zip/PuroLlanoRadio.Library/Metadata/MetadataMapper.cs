using PuroLlanoRadio.Database.Entities;
using PuroLlanoRadio.Library.Models;
using PuroLlanoRadio.Models.Entities;

namespace PuroLlanoRadio.Library.Metadata;

public static class MetadataMapper
{
    /// <summary>
    /// Convierte un <see cref="TrackInfo"/> al modelo de base de datos <see cref="TrackEntity"/>.
    /// Usado por el motor de persistencia (EF Core).
    /// </summary>
    public static TrackEntity ToEntity(TrackInfo info)
    {
        return new TrackEntity
        {
            Id        = Guid.NewGuid(),
            Title     = info.Title,
            Artist    = info.Artist,
            Album     = info.Album,
            Genre     = info.Genre,
            Duration  = info.Duration.TotalSeconds,
            FilePath  = info.FilePath,
            CoverPath = info.CoverPath,
            AddedDate = info.AddedDate
        };
    }

    /// <summary>
    /// Convierte un <see cref="TrackInfo"/> al modelo de presentación <see cref="Track"/>.
    /// Usado por los ViewModels (DeckAViewModel, DeckBViewModel) al cargar una pista
    /// desde la automatización o la cola de reproducción.
    /// </summary>
    public static Track ToTrack(TrackInfo info)
    {
        return new Track
        {
            Id        = info.Id,
            Title     = info.Title,
            Artist    = info.Artist,
            Album     = info.Album,
            Genre     = info.Genre,
            Duration  = info.Duration.TotalSeconds,
            FilePath  = info.FilePath,
            CoverPath = info.CoverPath,
            AddedDate = info.AddedDate
        };
    }

    /// <summary>
    /// Convierte un <see cref="TrackEntity"/> a <see cref="TrackInfo"/> para el motor
    /// de la Biblioteca y la cola de automatización.
    /// </summary>
    public static TrackInfo ToInfo(TrackEntity entity)
    {
        return new TrackInfo
        {
            Id        = entity.Id,
            Title     = entity.Title,
            Artist    = entity.Artist,
            Album     = entity.Album,
            Genre     = entity.Genre,
            Duration  = TimeSpan.FromSeconds(entity.Duration),
            FilePath  = entity.FilePath,
            CoverPath = entity.CoverPath,
            AddedDate = entity.AddedDate
        };
    }
}
