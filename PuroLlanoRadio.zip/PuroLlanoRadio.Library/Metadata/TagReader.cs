﻿using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.Library.Metadata;

public class TagReader
{
    public TrackInfo ReadTags(string filePath)
    {
        return new TrackInfo
        {
            FilePath = filePath,
            Title = Path.GetFileNameWithoutExtension(filePath)
        };
    }
}
