﻿using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Models;
using NAudio.Wave;

namespace PuroLlanoRadio.Library.Metadata;

public class MetadataReader : IMetadataReader
{
    public Task<TrackInfo> ReadMetadataAsync(string filePath)
    {
        var track = new TrackInfo
        {
            FilePath = filePath,
            Title = Path.GetFileNameWithoutExtension(filePath),
            AddedDate = DateTime.UtcNow
        };

        try
        {
            using var reader = new AudioFileReader(filePath);
            track.Duration = reader.TotalTime;
        }
        catch
        {
            // If we can't read the duration, leave it as default (TimeSpan.Zero)
        }

        return Task.FromResult(track);
    }
}
