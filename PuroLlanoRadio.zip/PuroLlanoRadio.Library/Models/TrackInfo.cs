﻿namespace PuroLlanoRadio.Library.Models;

public class TrackInfo
{
    public Guid Id { get; set; }

    public string Title { get; set; } = "";

    public string Artist { get; set; } = "";

    public string Album { get; set; } = "";

    public string Genre { get; set; } = "";

    public int Bpm { get; set; }

    public string Key { get; set; } = "";

    public TimeSpan Duration { get; set; }

    public string FilePath { get; set; } = "";

    public string CoverPath { get; set; } = "";

    public DateTime AddedDate { get; set; }

    public DateTime LastPlayed { get; set; }

    public int PlayCount { get; set; }
}
