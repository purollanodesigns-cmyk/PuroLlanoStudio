﻿namespace PuroLlanoRadio.Library.Models;

public class FolderImport
{
    public string FolderPath { get; set; } = "";

    public bool Recursive { get; set; } = true;

    public List<string> Extensions { get; set; } = new();

    public DateTime StartedAt { get; set; }

    public DateTime CompletedAt { get; set; }

    public int FilesProcessed { get; set; }

    public int Errors { get; set; }
}
