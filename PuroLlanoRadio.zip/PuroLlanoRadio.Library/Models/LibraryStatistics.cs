﻿namespace PuroLlanoRadio.Library.Models;

public class LibraryStatistics
{
    public int TotalTracks { get; set; }

    public int TotalArtists { get; set; }

    public int TotalAlbums { get; set; }

    public int TotalGenres { get; set; }

    public TimeSpan TotalDuration { get; set; }

    public int TracksWithoutCover { get; set; }

    public int TracksWithoutMetadata { get; set; }
}
