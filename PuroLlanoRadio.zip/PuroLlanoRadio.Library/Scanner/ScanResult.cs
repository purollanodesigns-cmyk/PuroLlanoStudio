﻿using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.Library.Scanner;

public class ScanResult
{
    public List<TrackInfo> Tracks { get; set; } = new();

    public int FilesFound { get; set; }

    public int Errors { get; set; }

    public bool ScanCompleted { get; set; }
}
