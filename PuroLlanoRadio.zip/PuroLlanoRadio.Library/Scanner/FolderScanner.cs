﻿using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.Library.Scanner;

public class FolderScanner
{
    private readonly IMetadataReader _metadataReader;

    public FolderScanner(IMetadataReader metadataReader)
    {
        _metadataReader = metadataReader;
    }

    public async Task<ScanResult> ScanAsync(string folderPath, bool recursive = true)
    {
        var result = new ScanResult();
        var searchOption = recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
        var extensions = new[] { ".mp3", ".aac", ".wav", ".flac", ".ogg", ".m4a" };

        var files = Directory.GetFiles(folderPath, "*.*", searchOption)
            .Where(f => extensions.Contains(Path.GetExtension(f)!.ToLowerInvariant()));

        foreach (var file in files)
        {
            try
            {
                var track = await _metadataReader.ReadMetadataAsync(file);
                result.Tracks.Add(track);
                result.FilesFound++;
            }
            catch
            {
                result.Errors++;
            }
        }

        result.ScanCompleted = true;
        return result;
    }
}
