﻿namespace PuroLlanoRadio.Library.Scanner;

public static class FileDetector
{
    private static readonly string[] AudioExtensions =
    {
        ".mp3", ".aac", ".wav", ".flac", ".ogg", ".m4a"
    };

    public static bool IsAudioFile(string filePath)
    {
        var ext = Path.GetExtension(filePath)?.ToLowerInvariant();
        return ext != null && AudioExtensions.Contains(ext);
    }

    public static string GetFileType(string filePath)
    {
        return Path.GetExtension(filePath)?.ToLowerInvariant() ?? string.Empty;
    }
}
