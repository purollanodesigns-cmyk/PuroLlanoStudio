﻿using Microsoft.Extensions.DependencyInjection;
using PuroLlanoRadio.Library.Analyzer;
using PuroLlanoRadio.Library.Covers;
using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Metadata;
using PuroLlanoRadio.Library.Scanner;
using PuroLlanoRadio.Library.Services;

namespace PuroLlanoRadio.Library.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddLibrary(
        this IServiceCollection services)
    {
        services.AddScoped<ILibraryService, LibraryService>();
        services.AddScoped<IScannerService, ScannerService>();
        services.AddScoped<IMetadataReader, MetadataReader>();
        services.AddScoped<ICoverProvider, CoverProvider>();
        services.AddSingleton<FolderScanner>();
        services.AddSingleton<AudioAnalyzer>();
        services.AddSingleton<BpmDetector>();
        services.AddSingleton<DurationAnalyzer>();
        services.AddSingleton<CoverCache>();
        services.AddSingleton<TagReader>();

        return services;
    }
}
