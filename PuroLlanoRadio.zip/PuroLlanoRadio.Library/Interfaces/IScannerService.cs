﻿using PuroLlanoRadio.Library.Models;

using PuroLlanoRadio.Library.Scanner;

namespace PuroLlanoRadio.Library.Interfaces;

public interface IScannerService
{
    Task<ScanResult> ScanFolderAsync(string folderPath);

    Task<ScanResult> ScanFileAsync(string filePath);
}
