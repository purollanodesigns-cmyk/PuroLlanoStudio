﻿using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.Library.Interfaces;

public interface ILibraryService
{
    Task<TrackInfo> ImportTrackAsync(string filePath);

    Task<List<TrackInfo>> ImportFolderAsync(string folderPath);

    Task<List<TrackInfo>> GetAllTracksAsync();

    Task<List<TrackInfo>> SearchTracksAsync(string query);

    Task<LibraryStatistics> GetStatisticsAsync();
}
