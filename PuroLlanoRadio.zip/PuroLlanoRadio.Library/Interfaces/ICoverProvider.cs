﻿using PuroLlanoRadio.Library.Models;

using PuroLlanoRadio.Library.Covers;

namespace PuroLlanoRadio.Library.Interfaces;

public interface ICoverProvider
{
    Task<CoverResult> GetCoverAsync(string filePath);

    Task<CoverResult> SearchCoverAsync(string artist, string album);
}
