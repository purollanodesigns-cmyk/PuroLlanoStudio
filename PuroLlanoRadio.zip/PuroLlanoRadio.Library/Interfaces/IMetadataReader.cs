﻿using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.Library.Interfaces;

public interface IMetadataReader
{
    Task<TrackInfo> ReadMetadataAsync(string filePath);
}
