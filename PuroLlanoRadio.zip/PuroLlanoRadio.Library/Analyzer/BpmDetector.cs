﻿using PuroLlanoRadio.AudioPipeline.Frames;

namespace PuroLlanoRadio.Library.Analyzer;

public class BpmDetector
{
    public Task<int> DetectBpmAsync(AudioFrame frame)
    {
        return Task.FromResult(0);
    }
}
