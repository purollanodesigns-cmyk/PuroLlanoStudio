﻿using PuroLlanoRadio.AudioPipeline.Frames;

namespace PuroLlanoRadio.Library.Analyzer;

public class AudioAnalyzer
{
    public async Task<AnalysisResult> AnalyzeAsync(AudioFrame frame)
    {
        return await Task.FromResult(new AnalysisResult
        {
            Duration = TimeSpan.FromSeconds(frame.Data.Length / (float)frame.Format.SampleRate),
            SampleRate = frame.Format.SampleRate,
            Channels = frame.Format.Channels
        });
    }
}
