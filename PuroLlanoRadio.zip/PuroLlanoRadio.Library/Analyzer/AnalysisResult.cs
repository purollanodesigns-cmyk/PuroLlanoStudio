﻿namespace PuroLlanoRadio.Library.Analyzer;

public class AnalysisResult
{
    public TimeSpan Duration { get; set; }

    public int SampleRate { get; set; }

    public int Channels { get; set; }

    public int Bpm { get; set; }
}
