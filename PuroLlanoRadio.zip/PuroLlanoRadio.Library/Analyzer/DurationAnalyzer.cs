﻿using PuroLlanoRadio.AudioPipeline.Frames;

namespace PuroLlanoRadio.Library.Analyzer;

public class DurationAnalyzer
{
    public TimeSpan GetDuration(AudioFrame frame)
    {
        if (frame.Format.SampleRate == 0 || frame.Data.Length == 0)
            return TimeSpan.Zero;

        var seconds = frame.Data.Length / (float)frame.Format.SampleRate;
        return TimeSpan.FromSeconds(seconds);
    }

    public TimeSpan GetDurationFromFile(string filePath)
    {
        return TimeSpan.Zero;
    }
}
