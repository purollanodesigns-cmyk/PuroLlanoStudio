﻿namespace PuroLlanoRadio.Library.Covers;

public class CoverResult
{
    public bool HasCover { get; set; }

    public string? FilePath { get; set; }

    public string? CoverPath { get; set; }

    public string? Source { get; set; }
}
