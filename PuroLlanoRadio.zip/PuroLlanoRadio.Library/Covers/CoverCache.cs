﻿using System.Collections.Concurrent;

namespace PuroLlanoRadio.Library.Covers;

public class CoverCache
{
    private readonly ConcurrentDictionary<string, string> _cache = new();

    public void Store(string trackPath, string coverPath)
    {
        _cache[trackPath] = coverPath;
    }

    public string? TryGet(string trackPath)
    {
        return _cache.TryGetValue(trackPath, out var coverPath) ? coverPath : null;
    }

    public void Clear()
    {
        _cache.Clear();
    }
}
