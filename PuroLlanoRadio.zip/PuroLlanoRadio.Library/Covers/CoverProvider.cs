﻿using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.Library.Covers;

public class CoverProvider : ICoverProvider
{
    public Task<CoverResult> GetCoverAsync(string filePath)
    {
        return Task.FromResult(new CoverResult
        {
            FilePath = filePath,
            HasCover = false
        });
    }

    public Task<CoverResult> SearchCoverAsync(string artist, string album)
    {
        return Task.FromResult(new CoverResult
        {
            HasCover = false
        });
    }
}
