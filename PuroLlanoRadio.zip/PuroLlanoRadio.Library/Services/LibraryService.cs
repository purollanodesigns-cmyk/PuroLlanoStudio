﻿using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Models;
using PuroLlanoRadio.Library.Scanner;

namespace PuroLlanoRadio.Library.Services;

public class LibraryService : ILibraryService
{
    private readonly FolderScanner _scanner;

    public LibraryService(FolderScanner scanner)
    {
        _scanner = scanner;
    }

    public async Task<TrackInfo> ImportTrackAsync(string filePath)
    {
        var result = await _scanner.ScanAsync(Path.GetDirectoryName(filePath)!, false);
        return result.Tracks.First(t => t.FilePath == filePath);
    }

    public async Task<List<TrackInfo>> ImportFolderAsync(string folderPath)
    {
        var result = await _scanner.ScanAsync(folderPath);
        return result.Tracks;
    }

    public Task<List<TrackInfo>> GetAllTracksAsync()
    {
        return Task.FromResult(new List<TrackInfo>());
    }

    public Task<List<TrackInfo>> SearchTracksAsync(string query)
    {
        return Task.FromResult(new List<TrackInfo>());
    }

    public Task<LibraryStatistics> GetStatisticsAsync()
    {
        return Task.FromResult(new LibraryStatistics());
    }
}
