﻿using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Scanner;

namespace PuroLlanoRadio.Library.Services;

public class ScannerService : IScannerService
{
    public Task<ScanResult> ScanFolderAsync(string folderPath)
    {
        return Task.FromResult(new ScanResult());
    }

    public Task<ScanResult> ScanFileAsync(string filePath)
    {
        return Task.FromResult(new ScanResult());
    }
}
