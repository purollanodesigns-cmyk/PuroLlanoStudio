﻿using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Clocks;

public class ClockScheduler : IClockScheduler
{
    private readonly List<ClockTemplate> _templates = new();

    public void AddTemplate(ClockTemplate template)
    {
        _templates.Add(template);
    }

    public async Task<PlaylistItem?> GetScheduledItemAsync(DateTime time)
    {
        var timeOfDay = time.TimeOfDay;

        foreach (var template in _templates)
        {
            if (timeOfDay >= template.StartTime && timeOfDay <= template.EndTime)
            {
                var block = template.Blocks.FirstOrDefault();
                if (block != null)
                {
                    return new PlaylistItem
                    {
                        Title = block.Content,
                        Type = block.Type,
                        ScheduledTime = time
                    };
                }
            }
        }

        return await Task.FromResult<PlaylistItem?>(null);
    }

    public Task<bool> IsScheduledAsync(DateTime time)
    {
        var timeOfDay = time.TimeOfDay;
        var isScheduled = _templates.Any(t => timeOfDay >= t.StartTime && timeOfDay <= t.EndTime);
        return Task.FromResult(isScheduled);
    }
}
