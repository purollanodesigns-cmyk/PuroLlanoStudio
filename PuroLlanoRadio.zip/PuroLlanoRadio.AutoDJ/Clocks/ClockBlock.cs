﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Clocks;

public class ClockBlock
{
    public int Position { get; set; }

    public PlaylistType Type { get; set; } = PlaylistType.Song;

    public string Content { get; set; } = "";

    public TimeSpan Duration { get; set; }
}
