﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Clocks;

public class ClockTemplate
{
    public string Name { get; set; } = "";

    public TimeSpan StartTime { get; set; }

    public TimeSpan EndTime { get; set; }

    public List<ClockBlock> Blocks { get; set; } = new();
}
