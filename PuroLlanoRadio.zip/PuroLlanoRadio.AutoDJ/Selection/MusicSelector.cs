﻿using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.AutoDJ.Selection;

public class MusicSelector : IMusicSelector
{
    public Task<TrackInfo?> SelectAsync(SelectionCriteria criteria)
    {
        return Task.FromResult<TrackInfo?>(null);
    }

    public Task<SelectionScore> ScoreAsync(TrackInfo track, SelectionCriteria criteria)
    {
        var score = new SelectionScore
        {
            TrackId = track.Id,
            Score = 1.0,
            Reason = "Initial selection"
        };

        return Task.FromResult(score);
    }
}
