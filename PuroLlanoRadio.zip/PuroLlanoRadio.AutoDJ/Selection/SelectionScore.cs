﻿namespace PuroLlanoRadio.AutoDJ.Selection;

public class SelectionScore
{
    public Guid TrackId { get; set; }

    public double Score { get; set; }

    public string Reason { get; set; } = "";

    public List<string> Factors { get; set; } = new();
}
