﻿using PuroLlanoRadio.Contracts.Enums;

namespace PuroLlanoRadio.AutoDJ.Selection;

public class SelectionCriteria
{
    public string Genre { get; set; } = "";

    public string Artist { get; set; } = "";

    public TimeSpan MinDuration { get; set; }

    public TimeSpan MaxDuration { get; set; }

    public DateTime TargetTime { get; set; }

    public int MaximumPlays { get; set; }

    public List<Guid> ExcludedTracks { get; set; } = new();
}
