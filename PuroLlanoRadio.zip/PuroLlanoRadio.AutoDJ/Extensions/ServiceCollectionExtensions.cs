﻿using Microsoft.Extensions.DependencyInjection;
using PuroLlanoRadio.AutoDJ.Clocks;
using PuroLlanoRadio.AutoDJ.Engine;
using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.AutoDJ.Playlist;
using PuroLlanoRadio.AutoDJ.Rotation;
using PuroLlanoRadio.AutoDJ.Rules;
using PuroLlanoRadio.AutoDJ.Selection;

namespace PuroLlanoRadio.AutoDJ.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddAutoDj(
        this IServiceCollection services)
    {
        services.AddSingleton<IAutoDjEngine, AutoDjEngine>();
        services.AddSingleton<IPlaylistGenerator, PlaylistGenerator>();
        services.AddSingleton<IMusicSelector, MusicSelector>();
        services.AddSingleton<IRotationEngine, RotationEngine>();
        services.AddSingleton<IClockScheduler, ClockScheduler>();
        services.AddSingleton<RuleEngine>();
        services.AddSingleton<PlaylistQueue>();

        // Smart Rotation.
        // The selector depends on ILibraryService, which belongs
        // to the Library container and is already registered there.
        services.AddScoped<ISmartRotationSelector, SmartRotationSelector>();

        return services;
    }
}
