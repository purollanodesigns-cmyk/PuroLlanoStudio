﻿using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Engine;

public class AutoDjEngine : IAutoDjEngine
{
    private readonly IPlaylistGenerator _playlistGenerator;

    public AutoDjEngine(IPlaylistGenerator playlistGenerator)
    {
        _playlistGenerator = playlistGenerator;
    }

    public Task StartAsync()
    {
        return Task.CompletedTask;
    }

    public Task StopAsync()
    {
        return Task.CompletedTask;
    }

    public Task<PlaylistItem?> GetNextTrackAsync()
    {
        return Task.FromResult<PlaylistItem?>(null);
    }

    public Task<List<PlaylistItem>> GetPlaylistAsync(int count)
    {
        return _playlistGenerator.GenerateAsync(count);
    }

    public bool IsPlaying { get; private set; }
}
