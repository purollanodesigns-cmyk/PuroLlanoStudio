namespace PuroLlanoRadio.AutoDJ.Engine;

public class AutomationConfig
{
    public bool AutomationEnabled { get; set; } = false;
    public bool CrossfadeEnabled { get; set; } = true;
    public double CrossfadeDurationSeconds { get; set; } = 5.0;
    public bool AutoAdvance { get; set; } = true;
    public bool AvoidImmediateRepeat { get; set; } = true;
}
