namespace PuroLlanoRadio.AutoDJ.Engine;

public enum AutomationState
{
    Disabled,
    Idle,
    Preloading,
    Playing,
    Crossfading,
    Waiting,
    Error
}
