using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.AutoDJ.Playlist;
using PuroLlanoRadio.AutoDJ.Rotation;
using PuroLlanoRadio.Contracts.Enums;
using PuroLlanoRadio.Library.Metadata;
using PuroLlanoRadio.Library.Models;
using PuroLlanoRadio.Mixer.Interfaces;
using PuroLlanoRadio.Models.Entities;

namespace PuroLlanoRadio.AutoDJ.Engine;

public sealed class AutomationEngine : IAutomationEngine, IDisposable
{
    // ─── CORRECCIÓN #1 ──────────────────────────────────────────────────────
    // Antes: `private readonly dynamic _deckAVm;` / `_deckBVm`.
    // El uso de `dynamic` desactivaba la comprobación en tiempo de compilación
    // de todas las llamadas (.State, .PlayCommand, .LoadTrackAsync(...), .Title,
    // .Duration) y las resolvía en runtime vía el DLR, lo que además es más
    // lento y oculta errores hasta que el código realmente se ejecuta.
    // Ahora dependemos de la interfaz IDeckViewModel, implementada por
    // DeckAViewModel y DeckBViewModel (ver patch adjunto).
    private readonly IDeckViewModel _deckAVm;
    private readonly IDeckViewModel _deckBVm;
    private readonly IMixerEngine _mixerEngine;

    private IMixerChannel? _channelA;
    private IMixerChannel? _channelB;
    private bool _channelWarningLogged;

    private AutomationState _state = AutomationState.Disabled;
    private char _activeDeck = 'A';
    private char _nextDeck = 'B';

    private bool _isTransitioning;
    private bool _isRunning;

    private CancellationTokenSource? _automationCts;
    private CancellationTokenSource? _crossfadeCts;
    private Task? _automationLoopTask;

    private readonly SemaphoreSlim _transitionGate = new(1, 1);

    private Track? _lastPlayedTrack;

    // ─── CORRECCIÓN #2 ──────────────────────────────────────────────────────
    // Se registra qué Track quedó cargado en cada deck en el momento del
    // precarga. Antes, _lastPlayedTrack solo se fijaba una vez, en
    // StartAutomationAsync, y nunca se actualizaba tras cada crossfade — por
    // lo que "AvoidImmediateRepeat" solo funcionaba para la primera
    // transición y quedaba inerte el resto de la sesión.
    private readonly Dictionary<char, Track?> _deckTracks = new() { ['A'] = null, ['B'] = null };

    private readonly ISmartRotationSelector _rotationSelector;

    public AutomationConfig Config { get; } = new AutomationConfig();
    public PlaylistQueue Queue { get; } = new PlaylistQueue();
    public PlaylistItem? NextTrack => Queue.Peek();

    public AutomationState State
    {
        get => _state;
        private set
        {
            if (_state == value)
                return;

            _state = value;
            Log($"[AUTOMATION] State → {_state}");
            StateChanged?.Invoke(this, _state);
        }
    }

    public char ActiveDeck
    {
        get => _activeDeck;
        private set
        {
            if (_activeDeck == value)
                return;

            _activeDeck = value;
            _nextDeck = value == 'A' ? 'B' : 'A';

            Log($"[AUTOMATION] Active Deck = {_activeDeck}");
            ActiveDeckChanged?.Invoke(this, _activeDeck);
        }
    }

    public char NextDeck => _nextDeck;

    public event EventHandler<AutomationState>? StateChanged;
    public event EventHandler<char>? ActiveDeckChanged;
    public event EventHandler<PlaylistItem?>? NextTrackChanged;
    public event EventHandler? QueueChanged;

    // ─── CORRECCIÓN #1 (constructor) ────────────────────────────────────────
    // Antes: `AutomationEngine(object deckAVm, object deckBVm, IMixerEngine mixerEngine)`.
    public AutomationEngine(IDeckViewModel deckAVm, IDeckViewModel deckBVm, IMixerEngine mixerEngine, ISmartRotationSelector rotationSelector)
    {
        _deckAVm = deckAVm ?? throw new ArgumentNullException(nameof(deckAVm));
        _deckBVm = deckBVm ?? throw new ArgumentNullException(nameof(deckBVm));
        _mixerEngine = mixerEngine ?? throw new ArgumentNullException(nameof(mixerEngine));
        _rotationSelector = rotationSelector ?? throw new ArgumentNullException(nameof(rotationSelector));

        ResolveChannels();
    }

    private void Log(string message)
    {
        Debug.WriteLine(message);
        Console.WriteLine(message);
    }

    // ─── CORRECCIÓN #3 ──────────────────────────────────────────────────────
    // Antes, si "DeckA"/"DeckB" no se encontraban en _mixerEngine.Channels, los
    // campos _channelA/_channelB quedaban en null silenciosamente: el
    // crossfade seguía "funcionando" (el bucle de progreso corría) pero nunca
    // movía ganancia real en el mezclador, y no había ninguna pista en el log
    // de por qué el audio no bajaba/subía en la transición.
    private void ResolveChannels()
    {
        _channelA = _mixerEngine.Channels.FirstOrDefault(
            c => c.Name.Equals("DeckA", StringComparison.OrdinalIgnoreCase) ||
                 c.Name.Equals("DECK A", StringComparison.OrdinalIgnoreCase));

        _channelB = _mixerEngine.Channels.FirstOrDefault(
            c => c.Name.Equals("DeckB", StringComparison.OrdinalIgnoreCase) ||
                 c.Name.Equals("DECK B", StringComparison.OrdinalIgnoreCase));

        if ((_channelA == null || _channelB == null) && !_channelWarningLogged)
        {
            _channelWarningLogged = true;
            Log($"[AUTOMATION WARNING] No se pudieron resolver los canales del mezclador " +
                $"(DeckA={(_channelA != null ? "OK" : "NO ENCONTRADO")}, " +
                $"DeckB={(_channelB != null ? "OK" : "NO ENCONTRADO")}). " +
                "El crossfade avanzará sin mover ganancia real.");
        }
        else if (_channelA != null && _channelB != null)
        {
            _channelWarningLogged = false;
        }
    }

    public void EnqueueTrack(Track track)
    {
        if (track == null)
            return;

        var info = new TrackInfo
        {
            Id = track.Id,
            Title = track.Title,
            Artist = track.Artist,
            Album = track.Album,
            Genre = track.Genre,
            Duration = TimeSpan.FromSeconds(Math.Max(0, track.Duration)),
            FilePath = track.FilePath,
            CoverPath = track.CoverPath,
            AddedDate = track.AddedDate
        };

        var item = new PlaylistItem
        {
            Id = Guid.NewGuid(),
            Track = info,
            Title = info.Title,
            DurationSeconds = (int)Math.Max(0, Math.Round(info.Duration.TotalSeconds)),
            Duration = info.Duration,
            ScheduledTime = DateTime.UtcNow
        };

        Queue.Enqueue(item);
        Log($"[AUTOMATION DEBUG] ENQUEUE | {item.Title} | {item.Duration:mm\\:ss}");
        NotifyQueueUpdated();
    }

    public void RemoveFromQueue(int index)
    {
        if (Queue.RemoveAt(index))
            NotifyQueueUpdated();
    }

    public void MoveQueueUp(int index)
    {
        if (Queue.MoveUp(index))
            NotifyQueueUpdated();
    }

    public void MoveQueueDown(int index)
    {
        if (Queue.MoveDown(index))
            NotifyQueueUpdated();
    }

    public void ClearQueue()
    {
        Queue.Clear();
        NotifyQueueUpdated();
    }

    private void NotifyQueueUpdated()
    {
        QueueChanged?.Invoke(this, EventArgs.Empty);
        NextTrackChanged?.Invoke(this, NextTrack);
    }

    public async Task StartAutomationAsync()
    {
        var stackTrace = Environment.StackTrace;

        Debug.WriteLine(
            $"[AUTOMATION START TRACE]\n{stackTrace}");

        Console.WriteLine(
            $"[AUTOMATION START TRACE]\n{stackTrace}");

        if (_isRunning)
        {
            Log("[AUTOMATION] StartAutomation ignored — already running");
            return;
        }

        if (Queue.Count == 0)
        {
            Config.AutomationEnabled = true;
            _isRunning = true;
            State = AutomationState.Waiting;
            EnsureAutomationLoopStarted();
            Log("[AUTOMATION] Started in WAITING — queue empty");
            return;
        }

        Config.AutomationEnabled = true;
        _isRunning = true;
        _isTransitioning = false;
        ActiveDeck = 'A';
        ResolveChannels();

        _automationCts?.Cancel();
        _automationCts?.Dispose();
        _automationCts = new CancellationTokenSource();

        State = AutomationState.Preloading;

        var firstItem = Queue.Dequeue();
        NotifyQueueUpdated();

        if (firstItem?.Track == null)
        {
            State = AutomationState.Waiting;
            EnsureAutomationLoopStarted();
            return;
        }

        var firstTrack = MetadataMapper.ToTrack(firstItem.Track);
        _lastPlayedTrack = firstTrack;
        _deckTracks['A'] = firstTrack;

        await _deckAVm.LoadTrackAsync(firstTrack).ConfigureAwait(false);

        // Inicialización de ganancia de sesión vía MixerEngine (nunca vía canal).
        if (_mixerEngine.GetChannel("DECK A") is IGainAutomatable deckA)
            deckA.SetGainImmediate(1.0);
        if (_mixerEngine.GetChannel("DECK B") is IGainAutomatable deckB)
            deckB.SetGainImmediate(0.0);

        if (_deckAVm.State != PlaybackState.Ready)
        {
            Log("[AUTOMATION] Active Deck A failed to reach Ready");
            State = AutomationState.Error;
            return;
        }

        // ─── CORRECCIÓN #4 ──────────────────────────────────────────────────
        // Antes, si PlayCommand.Execute lanzaba una excepción (por ejemplo un
        // fallo del reproductor de audio subyacente), la excepción escapaba
        // sin control y podía tumbar el loop de automatización o la app.
        // Ahora se captura, se registra y el motor pasa a Error de forma
        // controlada.

        try
        {
            Log($"[AUTOMATION PLAY SOURCE] Source=StartAutomationAsync Deck=A State={_deckAVm.State}");
            _deckAVm.PlayCommand.Execute(null);
        }
        catch (Exception ex)
        {
            Log($"[AUTOMATION] Exception starting Deck A: {ex.Message}");
            State = AutomationState.Error;
            return;
        }

        if (!await WaitForDeckPlaybackStartAsync(_deckAVm, 'A', _automationCts.Token).ConfigureAwait(false))
        {
            Log($"[AUTOMATION] Deck A did not start consuming audio. State={_deckAVm.State} Position={_deckAVm.Position:mm\\:ss}");
            State = AutomationState.Error;
            return;
        }

        State = AutomationState.Playing;
        LogActiveTrack(_deckAVm);

        await PreloadNextDeckAsync().ConfigureAwait(false);

        EnsureAutomationLoopStarted();
    }

    public async Task StopAutomationAsync()
    {
        Config.AutomationEnabled = false;
        _isRunning = false;
        _isTransitioning = false;

        _crossfadeCts?.Cancel();
        _automationCts?.Cancel();

        var loop = _automationLoopTask;
        _automationLoopTask = null;

        if (loop != null)
        {
            try
            {
                await loop.ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                // Cancelación esperada al detener el loop.
            }
        }
    }

    public async Task TriggerNextAsync()
    {
        var stackTrace = Environment.StackTrace;

        Debug.WriteLine($"[AUTOMATION TRIGGER TRACE]\n{stackTrace}");
        Console.WriteLine($"[AUTOMATION TRIGGER TRACE]\n{stackTrace}");

        await _transitionGate.WaitAsync().ConfigureAwait(false);

        try
        {
            IDeckViewModel outgoingVm =
                ActiveDeck == 'A' ? _deckAVm : _deckBVm;

            char incomingDeck = NextDeck;

            IDeckViewModel incomingVm =
                incomingDeck == 'A' ? _deckAVm : _deckBVm;

            if (!_isRunning || _isTransitioning)
                return;

            if (incomingVm.State != PlaybackState.Ready)
            {
                Log(
                    $"[AUTOMATION] No ready track on next deck: " +
                    $"{incomingDeck} State={incomingVm.State}");

                State = AutomationState.Waiting;
                return;
            }

            // ------------------------------------------------------------
            // BLOQUEAR TODA LA OPERACIÓN DE TRANSICIÓN.
            //
            // IMPORTANTE:
            // _isTransitioning permanece TRUE hasta que el deck saliente
            // haya sido preparado para la siguiente pista.
            // Esto evita que RunAutomationLoopAsync() entre concurrentemente
            // y consuma la Queue mientras PreloadSpecificDeckAsync() trabaja.
            // ------------------------------------------------------------
            _isTransitioning = true;
            State = AutomationState.Crossfading;

            try
            {
                Log(
                    $"[AUTOMATION PLAY SOURCE] " +
                    $"Source=TriggerNextAsync " +
                    $"Deck={incomingDeck} " +
                    $"State={incomingVm.State}");

                incomingVm.PlayCommand.Execute(null);
            }
            catch (Exception ex)
            {
                Log(
                    $"[AUTOMATION] Exception starting Deck " +
                    $"{incomingDeck}: {ex.Message}");

                State = AutomationState.Error;
                _isTransitioning = false;
                return;
            }

            // Confirmar que el deck entrante realmente comenzó
            // a consumir audio antes de ejecutar el crossfade.
            if (!await WaitForDeckPlaybackStartAsync(
                    incomingVm,
                    incomingDeck,
                    _automationCts?.Token ?? CancellationToken.None)
                .ConfigureAwait(false))
            {
                Log(
                    $"[AUTOMATION] Deck {incomingDeck} failed to start " +
                    $"consuming audio. State={incomingVm.State} " +
                    $"Position={incomingVm.Position:mm\\:ss}");

                State = AutomationState.Error;
                _isTransitioning = false;
                return;
            }

            _crossfadeCts?.Cancel();
            _crossfadeCts?.Dispose();

            _crossfadeCts =
                CancellationTokenSource.CreateLinkedTokenSource(
                    _automationCts?.Token ?? CancellationToken.None);

            try
            {
                await _mixerEngine.CrossfadeAsync(
                    ActiveDeck == 'A' ? "DECK A" : "DECK B",
                    incomingDeck == 'A' ? "DECK A" : "DECK B",
                    TimeSpan.FromSeconds(
                        Math.Max(
                            0.1,
                            Config.CrossfadeDurationSeconds)),
                    _crossfadeCts.Token)
                    .ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                return;
            }

            // ------------------------------------------------------------
            // CAMBIAR EL DECK ACTIVO SOLO DESPUÉS DEL CROSSFADE REAL.
            // ------------------------------------------------------------
            var previousDeck = ActiveDeck;

            ActiveDeck = incomingDeck;

            _lastPlayedTrack =
                _deckTracks[ActiveDeck] ?? _lastPlayedTrack;

            LogActiveTrack(incomingVm);

            State = AutomationState.Playing;

            Log(
                $"[AUTOMATION TRANSITION COMPLETE] " +
                $"ActiveDeck={ActiveDeck} " +
                $"PreviousDeck={previousDeck}");

            // ------------------------------------------------------------
            // PREPARAR EL DECK SALIENTE MIENTRAS LA TRANSICIÓN SIGUE
            // BLOQUEADA.
            //
            // NO poner _isTransitioning=false antes de esta llamada.
            // ------------------------------------------------------------
            Log(
                $"[AUTOMATION PRELOAD NEXT] " +
                $"Preparing Deck {previousDeck} " +
                $"while transition gate is locked.");

            await PreloadSpecificDeckAsync(previousDeck)
                .ConfigureAwait(false);

            // ------------------------------------------------------------
            // VERIFICACIÓN FINAL DEL DECK PREPARADO.
            // ------------------------------------------------------------
            IDeckViewModel preparedVm =
                previousDeck == 'A' ? _deckAVm : _deckBVm;

            if (Queue.Count > 0)
            {
                Log(
                    $"[AUTOMATION POST-PRELOAD] " +
                    $"Deck={previousDeck} " +
                    $"State={preparedVm.State} " +
                    $"Queue={Queue.Count}");
            }
            else
            {
                Log(
                    $"[AUTOMATION POST-PRELOAD] " +
                    $"Deck={previousDeck} " +
                    $"State={preparedVm.State} " +
                    $"Queue=0");
            }

            // ------------------------------------------------------------
            // AHORA SÍ termina la transición.
            // RunAutomationLoopAsync() puede volver a revisar la cola.
            // ------------------------------------------------------------
            _isTransitioning = false;

            Log(
                $"[AUTOMATION TRANSITION UNLOCKED] " +
                $"ActiveDeck={ActiveDeck} " +
                $"NextDeck={NextDeck}");
        }
        finally
        {
            _transitionGate.Release();
        }
    }

    private async Task PreloadNextDeckAsync()
    {
        if (!Config.AutomationEnabled || !_isRunning)
            return;

        if (Queue.Count == 0)
        {
            await EnsureNextTrackAvailableAsync().ConfigureAwait(false);
        }

        if (Queue.Count == 0)
        {
            Log("[AUTOMATION] Queue empty — waiting for new tracks");
            return;
        }

        var targetDeck = NextDeck;
        await PreloadDeckFromQueueAsync(targetDeck, allowReplacePlaying: false).ConfigureAwait(false);
    }

    private async Task PreloadSpecificDeckAsync(char targetDeck)
    {
        if (!Config.AutomationEnabled || !_isRunning)
            return;

        if (Queue.Count == 0)
        {
            await EnsureNextTrackAvailableAsync().ConfigureAwait(false);
        }

        if (Queue.Count == 0)
        {
            Log("[AUTOMATION] Queue empty — waiting for new tracks");
            return;
        }

        await PreloadDeckFromQueueAsync(targetDeck, allowReplacePlaying: true).ConfigureAwait(false);
    }

    private async Task PreloadDeckFromQueueAsync(char targetDeck, bool allowReplacePlaying = false)
    {
        IDeckViewModel targetVm = targetDeck == 'A' ? _deckAVm : _deckBVm;

        if (targetVm.State == PlaybackState.Loading)
        {
            return;
        }

        if (targetVm.State == PlaybackState.Playing &&
            !allowReplacePlaying)
        {
            return;
        }

        if (targetVm.State == PlaybackState.Ready)
        {
            Log($"[AUTOMATION] Deck {targetDeck} already READY — no new preload");
            return;
        }

        var item = DequeueNextEligibleItem();
        if (item?.Track == null)
        {
            Log("[AUTOMATION] Queue empty — waiting for new tracks");
            State = AutomationState.Waiting;
            return;
        }

        var track = MetadataMapper.ToTrack(item.Track);

        try
        {
            await targetVm.LoadTrackAsync(track).ConfigureAwait(false);

            if (targetVm.State == PlaybackState.Ready)
            {
                _deckTracks[targetDeck] = track;

                Log($"[AUTOMATION] Preloaded Deck {targetDeck}: {item.Title}");
                Log($"[AUTOMATION] Deck {targetDeck} READY — waiting for transition point");
                NotifyQueueUpdated();
            }
            else
            {
                Log($"[AUTOMATION] Deck {targetDeck} did not reach Ready. State={targetVm.State}");
                Queue.Enqueue(item);
                NotifyQueueUpdated();
            }
        }
        catch (Exception ex)
        {
            Log($"[AUTOMATION] Failed to preload next track on Deck {targetDeck}: {ex.Message}");
            Queue.Enqueue(item);
            NotifyQueueUpdated();
        }
    }

    // ─── CORRECCIÓN #6 ──────────────────────────────────────────────────────
    // Antes, si la pista repetida seguía estando al frente después de un solo
    // "rotar al final", el método la devolvía igual (solo se comprobaba una
    // vez). Con una cola de 2 elementos donde ambos apuntan al mismo archivo
    // (o con AvoidImmediateRepeat mal configurado tras varias vueltas), podía
    // colarse una repetición inmediata pese a tener la opción activada.
    // Ahora se rota como máximo Queue.Count veces, buscando activamente un
    // candidato distinto antes de rendirse.
    private PlaylistItem? DequeueNextEligibleItem()
    {
        if (Queue.Count == 0)
            return null;

        if (!Config.AvoidImmediateRepeat || _lastPlayedTrack == null || Queue.Count <= 1)
            return Queue.Dequeue();

        var attempts = Queue.Count;

        for (var i = 0; i < attempts; i++)
        {
            var candidate = Queue.Peek();

            if (candidate?.Track == null)
                return Queue.Dequeue();

            var candidateTrack = MetadataMapper.ToTrack(candidate.Track);

            if (!candidateTrack.FilePath.Equals(_lastPlayedTrack.FilePath, StringComparison.OrdinalIgnoreCase))
                return Queue.Dequeue();

            // Es la misma pista que se acaba de reproducir: rotarla al final
            // e intentar con el siguiente candidato.
            var skipped = Queue.Dequeue();
            if (skipped != null)
                Queue.Enqueue(skipped);

            NotifyQueueUpdated();
        }

        // Todos los elementos de la cola son la misma pista repetida — no hay
        // alternativa real, así que se reproduce igualmente en vez de bloquear
        // la automatización.
        return Queue.Dequeue();
    }

    private async Task EnsureNextTrackAvailableAsync(CancellationToken cancellationToken = default)
    {
        // La cola explícita siempre tiene prioridad. La rotación inteligente
        // solo puede aportar una pista cuando la cola está realmente vacía.
        if (Queue.Count > 0)
            return;

        if (!_isRunning || !Config.AutomationEnabled || cancellationToken.IsCancellationRequested)
            return;

        var unavailableTrackIds = new HashSet<Guid>();

        Track? deckATrack = _deckTracks['A'];
        if (deckATrack != null)
            unavailableTrackIds.Add(deckATrack.Id);

        Track? deckBTrack = _deckTracks['B'];
        if (deckBTrack != null)
            unavailableTrackIds.Add(deckBTrack.Id);

        TrackInfo? selected = null;

        try
        {
            selected = await _rotationSelector.SelectNextAsync(
                unavailableTrackIds,
                cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception ex)
        {
            Log($"[AUTOMATION ROTATION] Selection error: {ex.Message}");
            return;
        }

        if (selected == null)
            return;

        var track = MetadataMapper.ToTrack(selected);
        EnqueueTrack(track);

        Log($"[AUTOMATION ROTATION] Selected={selected.Title} Artist={selected.Artist} Genre={selected.Genre} Duration={selected.Duration:mm\\:ss}");
    }

    private void EnsureAutomationLoopStarted()
    {
        if (!_isRunning)
            return;

        if (_automationLoopTask is { IsCompleted: false })
            return;

        var token = _automationCts?.Token ?? CancellationToken.None;
        _automationLoopTask = RunAutomationLoopAsync(token);
    }

    private async Task RunAutomationLoopAsync(CancellationToken cancellationToken)
    {
        try
        {
            while (_isRunning && !cancellationToken.IsCancellationRequested)
            {
                if (_isTransitioning)
                {
                    await Task.Delay(100, cancellationToken).ConfigureAwait(false);
                    continue;
                }

                IDeckViewModel activeVm = ActiveDeck == 'A' ? _deckAVm : _deckBVm;
                IDeckViewModel nextVm = NextDeck == 'A' ? _deckAVm : _deckBVm;

                if (activeVm.State == PlaybackState.Stopped ||
                    activeVm.State == PlaybackState.Paused)
                {
                    await Task.Delay(100, cancellationToken).ConfigureAwait(false);
                    continue;
                }

                if (activeVm.State == PlaybackState.Completed)
                {
                    if (nextVm.State == PlaybackState.Ready)
                    {
                        Log("[AUTOMATION LOOP] Trigger requested — active deck Completed, next Ready");
                        await TriggerNextAsync().ConfigureAwait(false);
                    }
                    else
                    {
                        await EnsureNextTrackAvailableAsync(cancellationToken).ConfigureAwait(false);

                        if (Queue.Count > 0)
                        {
                            await PreloadNextDeckAsync().ConfigureAwait(false);

                            if (nextVm.State == PlaybackState.Ready)
                            {
                                Log("[AUTOMATION LOOP] Trigger requested — after preload on Completed");
                                await TriggerNextAsync().ConfigureAwait(false);
                            }
                        }
                        else
                        {
                            State = AutomationState.Waiting;
                        }
                    }

                    await Task.Delay(100, cancellationToken).ConfigureAwait(false);
                    continue;
                }

                if (ShouldStartAutomaticCrossfade())
                {
                    Log("[AUTOMATION LOOP] Trigger requested from transition timer");
                    await TriggerNextAsync().ConfigureAwait(false);
                    continue;
                }

                if (activeVm.State == PlaybackState.Playing &&
                    nextVm.State != PlaybackState.Ready)
                {
                    await EnsureNextTrackAvailableAsync(cancellationToken).ConfigureAwait(false);

                    if (Queue.Count > 0)
                    {
                        await PreloadNextDeckAsync().ConfigureAwait(false);
                    }
                }

                await Task.Delay(100, cancellationToken).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
        }
    }

    private bool ShouldStartAutomaticCrossfade()
    {
        if (!_isRunning || _isTransitioning)
            return false;

        IDeckViewModel activeVm =
            ActiveDeck == 'A' ? _deckAVm : _deckBVm;

        IDeckViewModel nextVm =
            NextDeck == 'A' ? _deckAVm : _deckBVm;

        if (activeVm.State != PlaybackState.Playing)
            return false;

        if (nextVm.State != PlaybackState.Ready)
            return false;

        TimeSpan duration = activeVm.Duration;
        TimeSpan position = activeVm.Position;

        if (duration <= TimeSpan.Zero)
            return false;

        var crossfade = TimeSpan.FromSeconds(
            Math.Max(0.0, Config.CrossfadeDurationSeconds));

        if (crossfade >= duration)
        {
            crossfade = TimeSpan.FromSeconds(
                Math.Max(0.0, duration.TotalSeconds - 1.0));
        }

        var transitionPoint = duration - crossfade;

        if (position < transitionPoint)
            return false;

        return true;
    }

    private async Task<bool> WaitForDeckPlaybackStartAsync(
        IDeckViewModel deckVm,
        char deck,
        CancellationToken cancellationToken)
    {
        const int timeoutMilliseconds = 3000;
        const int pollMilliseconds = 100;

        var startedAt = DateTime.UtcNow;

        while (!cancellationToken.IsCancellationRequested)
        {
            if (deckVm.State == PlaybackState.Playing)
            {
                // El estado Playing es la confirmación principal.
                // Position puede permanecer en 00:00 durante los primeros
                // cientos de milisegundos porque el lector/mixer es asíncrono.
                if (deckVm.Position > TimeSpan.Zero)
                {
                    Log(
                        $"[AUTOMATION] Deck {deck} confirmed Playing " +
                        $"and consuming audio. Position={deckVm.Position:mm\\:ss}");

                    return true;
                }

                // Permitimos que el pipeline de audio tenga tiempo para
                // comenzar a consumir el reader.
                var elapsed = (DateTime.UtcNow - startedAt).TotalMilliseconds;

                if (elapsed >= timeoutMilliseconds)
                {
                    // State=Playing sigue siendo válido aunque Position siga
                    // temporalmente en cero. No convertir esto en Error.
                    Log(
                        $"[AUTOMATION] Deck {deck} confirmed Playing " +
                        $"but Position is still zero after timeout. " +
                        $"Continuing because State=Playing.");

                    return true;
                }
            }
            else if (deckVm.State == PlaybackState.Stopped ||
                     deckVm.State == PlaybackState.Completed ||
                     deckVm.State == PlaybackState.Error)
            {
                Log(
                    $"[AUTOMATION] Deck {deck} failed to start. " +
                    $"State={deckVm.State} Position={deckVm.Position:mm\\:ss}");

                return false;
            }

            await Task.Delay(
                pollMilliseconds,
                cancellationToken).ConfigureAwait(false);
        }

        return false;
    }

    private void LogActiveTrack(IDeckViewModel activeVm)
    {
        var title = string.IsNullOrWhiteSpace(activeVm.Title) ? "SIN TÍTULO" : activeVm.Title;
        var duration = activeVm.Duration;

        Log($"[AUTOMATION TRACK] NowPlaying={title} Duration={duration:mm\\:ss}");
        Log($"[AUTOMATION STATE FINAL] ActiveDeck={ActiveDeck} ActiveState={activeVm.State}");

        if (Queue.Count > 0 && Queue.Peek() != null)
        {
            var next = Queue.Peek()!;
            Log($"[AUTOMATION TRACK] Next={next.Title} NextDuration={next.Duration:mm\\:ss}");
        }
        else
        {
            Log("[AUTOMATION TRACK] Next=NO NEXT TRACK");
        }
    }

    public void Dispose()
    {
        try
        {
            _isRunning = false;
            Config.AutomationEnabled = false;

            _crossfadeCts?.Cancel();
            _automationCts?.Cancel();

            if (_automationLoopTask is { IsCompleted: false })
            {
                try
                {
                    _automationLoopTask.GetAwaiter().GetResult();
                }
                catch (OperationCanceledException)
                {
                }
            }
        }
        finally
        {
            _crossfadeCts?.Dispose();
            _crossfadeCts = null;

            _automationCts?.Dispose();
            _automationCts = null;

            _transitionGate.Dispose();
        }
    }
}