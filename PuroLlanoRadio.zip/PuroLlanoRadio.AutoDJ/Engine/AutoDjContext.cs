﻿namespace PuroLlanoRadio.AutoDJ.Engine;

public sealed class AutoDjContext
{
    public AutoDjState State { get; set; }

    public int QueueSize { get; set; }

    public string CurrentTrack { get; set; } = "";

    public int TotalTracksPlayed { get; set; }

    public DateTime LastTrackTime { get; set; }
}
