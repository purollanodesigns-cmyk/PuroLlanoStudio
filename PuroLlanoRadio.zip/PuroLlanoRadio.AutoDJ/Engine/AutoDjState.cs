﻿namespace PuroLlanoRadio.AutoDJ.Engine;

public enum AutoDjState
{
    Stopped,
    Loading,
    Playing,
    Paused,
    Error
}
