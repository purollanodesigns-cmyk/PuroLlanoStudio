﻿using PuroLlanoRadio.AutoDJ.Selection;
using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.AutoDJ.Interfaces;

public interface IMusicSelector
{
    Task<TrackInfo?> SelectAsync(SelectionCriteria criteria);

    Task<SelectionScore> ScoreAsync(TrackInfo track, SelectionCriteria criteria);
}
