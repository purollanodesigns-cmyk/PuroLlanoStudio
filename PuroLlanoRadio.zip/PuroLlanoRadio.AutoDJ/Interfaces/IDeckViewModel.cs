using System;
using System.Threading.Tasks;
using System.Windows.Input;
using PuroLlanoRadio.Contracts.Enums;
using PuroLlanoRadio.Models.Entities;

namespace PuroLlanoRadio.AutoDJ.Interfaces;

/// <summary>
/// Contrato mínimo que AutomationEngine necesita de un deck de reproducción
/// (DeckAViewModel / DeckBViewModel).
///
/// Antes, AutomationEngine recibía los ViewModels como <c>object</c> y los
/// invocaba vía <c>dynamic</c>. Eso desactivaba la comprobación en tiempo de
/// compilación: un cambio de nombre o de firma en DeckAViewModel no se
/// detectaba hasta una excepción en tiempo de ejecución (RuntimeBinderException),
/// y cada llamada dynamic paga el costo del DLR (Dynamic Language Runtime).
///
/// Con esta interfaz, DeckAViewModel/DeckBViewModel implementan el contrato
/// explícitamente y cualquier desalineación se detecta al compilar.
/// </summary>
public interface IDeckViewModel
{
    /// <summary>Título de la pista actualmente cargada en el deck.</summary>
    string Title { get; }

    /// <summary>Duración total de la pista cargada.</summary>
    TimeSpan Duration { get; }

    /// <summary>Posición actual de reproducción.</summary>
    TimeSpan Position { get; }

    /// <summary>Estado de reproducción actual del deck.</summary>
    PlaybackState State { get; }

    /// <summary>Comando que inicia la reproducción del deck.</summary>
    ICommand PlayCommand { get; }

    /// <summary>
    /// Carga una pista en el deck y espera a que el reproductor subyacente
    /// termine de prepararla (o falle).
    /// </summary>
    Task LoadTrackAsync(Track? track);
}