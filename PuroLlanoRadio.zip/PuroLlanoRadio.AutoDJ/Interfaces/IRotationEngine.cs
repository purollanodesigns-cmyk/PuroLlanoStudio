﻿namespace PuroLlanoRadio.AutoDJ.Interfaces;

public interface IRotationEngine
{
    Task<bool> CheckArtistRotationAsync(string artist, int minimumGap);

    Task<bool> CheckTrackRotationAsync(Guid trackId, int minutesSinceLast);

    Task<bool> CheckGenreRotationAsync(string genre, int minimumGap);

    Task RegisterPlayAsync(Guid trackId, string artist, string genre);
}
