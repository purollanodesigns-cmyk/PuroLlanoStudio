﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Interfaces;

public interface IAutoDjEngine
{
    Task StartAsync();

    Task StopAsync();

    Task<PlaylistItem?> GetNextTrackAsync();

    Task<List<PlaylistItem>> GetPlaylistAsync(int count);

    bool IsPlaying { get; }
}
