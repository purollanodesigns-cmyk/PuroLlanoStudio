﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Interfaces;

public interface IPlaylistGenerator
{
    Task<List<PlaylistItem>> GenerateAsync(int count);

    Task<PlaylistItem?> GetNextAsync();
}
