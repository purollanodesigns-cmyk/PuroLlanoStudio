using System;
using System.Threading.Tasks;
using PuroLlanoRadio.AutoDJ.Engine;
using PuroLlanoRadio.AutoDJ.Playlist;
using PuroLlanoRadio.Models.Entities;

namespace PuroLlanoRadio.AutoDJ.Interfaces;

public interface IAutomationEngine
{
    AutomationConfig Config { get; }
    AutomationState State { get; }
    char ActiveDeck { get; }
    char NextDeck { get; }
    PlaylistQueue Queue { get; }
    PlaylistItem? NextTrack { get; }

    event EventHandler<AutomationState>? StateChanged;
    event EventHandler<char>? ActiveDeckChanged;
    event EventHandler<PlaylistItem?>? NextTrackChanged;
    event EventHandler? QueueChanged;

    Task StartAutomationAsync();
    Task StopAutomationAsync();
    Task TriggerNextAsync();

    void EnqueueTrack(Track track);
    void RemoveFromQueue(int index);
    void MoveQueueUp(int index);
    void MoveQueueDown(int index);
    void ClearQueue();
}
