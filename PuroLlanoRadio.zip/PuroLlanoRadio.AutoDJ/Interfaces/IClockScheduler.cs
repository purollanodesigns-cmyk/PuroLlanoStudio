﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Interfaces;

public interface IClockScheduler
{
    Task<PlaylistItem?> GetScheduledItemAsync(DateTime time);

    Task<bool> IsScheduledAsync(DateTime time);
}
