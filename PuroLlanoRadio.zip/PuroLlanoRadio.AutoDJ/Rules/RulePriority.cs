﻿namespace PuroLlanoRadio.AutoDJ.Rules;

public enum RulePriority
{
    Low = 0,
    Normal = 1,
    High = 2,
    Critical = 3
}
