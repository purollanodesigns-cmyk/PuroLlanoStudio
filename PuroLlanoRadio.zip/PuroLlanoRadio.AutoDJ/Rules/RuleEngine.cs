﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Rules;

public class RuleEngine
{
    private readonly List<AutoDjRule> _rules = new();

    public void AddRule(AutoDjRule rule)
    {
        _rules.Add(rule);
    }

    public void RemoveRule(string name)
    {
        var rule = _rules.FirstOrDefault(r => r.Name == name);
        if (rule != null)
            _rules.Remove(rule);
    }

    public PlaylistItem? ApplyRules(PlaylistItem? item, DateTime currentTime)
    {
        var result = item;

        foreach (var rule in _rules.OrderBy(r => r.Priority))
        {
            if (rule.ShouldApply(currentTime))
            {
                result = rule.Apply(result);
            }
        }

        return result;
    }
}
