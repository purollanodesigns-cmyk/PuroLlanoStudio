﻿using PuroLlanoRadio.AutoDJ.Playlist;

namespace PuroLlanoRadio.AutoDJ.Rules;

public class AutoDjRule
{
    public string Name { get; set; } = "";

    public string Description { get; set; } = "";

    public RulePriority Priority { get; set; }

    public bool IsEnabled { get; set; } = true;

    public bool ShouldApply(DateTime currentTime)
    {
        return IsEnabled;
    }

    public PlaylistItem? Apply(PlaylistItem? item)
    {
        return item;
    }
}
