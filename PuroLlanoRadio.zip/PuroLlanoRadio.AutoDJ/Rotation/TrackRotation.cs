﻿public class TrackRotation
{
    private readonly Dictionary<Guid, DateTime> _lastPlayed = new();

    public int MinutesSinceLast { get; set; } = 60;

    public void RegisterPlay(Guid trackId)
    {
        _lastPlayed[trackId] = DateTime.UtcNow;
    }

    public bool CanPlay(Guid trackId)
    {
        if (!_lastPlayed.ContainsKey(trackId))
            return true;

        return (DateTime.UtcNow - _lastPlayed[trackId]).TotalMinutes >= MinutesSinceLast;
    }
}
