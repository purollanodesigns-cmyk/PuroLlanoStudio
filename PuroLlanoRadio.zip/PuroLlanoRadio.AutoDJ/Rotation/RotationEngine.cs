﻿using PuroLlanoRadio.AutoDJ.Interfaces;

namespace PuroLlanoRadio.AutoDJ.Rotation;

public class RotationEngine : IRotationEngine
{
    private readonly ArtistRotation _artistRotation = new();
    private readonly TrackRotation _TrackRotation = new();
    private readonly GenreRotation _genreRotation = new();

    public async Task<bool> CheckArtistRotationAsync(string artist, int minimumGap)
    {
        _artistRotation.MinimumGap = minimumGap;
        return await Task.FromResult(_artistRotation.CanPlay(artist));
    }

    public async Task<bool> CheckTrackRotationAsync(Guid trackId, int minutesSinceLast)
    {
        _TrackRotation.MinutesSinceLast = minutesSinceLast;
        return await Task.FromResult(_TrackRotation.CanPlay(trackId));
    }

    public async Task<bool> CheckGenreRotationAsync(string genre, int minimumGap)
    {
        _genreRotation.MinimumGap = minimumGap;
        return await Task.FromResult(_genreRotation.CanPlay(genre));
    }

    public async Task RegisterPlayAsync(Guid trackId, string artist, string genre)
    {
        _TrackRotation.RegisterPlay(trackId);
        _artistRotation.RegisterPlay(artist);
        _genreRotation.RegisterPlay(genre);
        await Task.CompletedTask;
    }
}
