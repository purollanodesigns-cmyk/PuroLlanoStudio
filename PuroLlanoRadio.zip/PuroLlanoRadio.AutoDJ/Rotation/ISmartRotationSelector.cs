using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using PuroLlanoRadio.Library.Models;


namespace PuroLlanoRadio.AutoDJ.Rotation;


public interface ISmartRotationSelector
{
    string PreferredGenre { get; set; }


    int ArtistRepeatAvoidance { get; set; }


    int HistorySize { get; set; }


    Task<TrackInfo?> SelectNextAsync(
        IReadOnlyCollection<Guid> unavailableTrackIds,
        CancellationToken cancellationToken = default);


    void RegisterPlayed(TrackInfo track);


    void ClearHistory();
}