﻿public class GenreRotation
{
    private readonly Dictionary<string, int> _recentPlays = new();

    public int MinimumGap { get; set; } = 4;

    public void RegisterPlay(string genre)
    {
        _recentPlays[genre] = _recentPlays.GetValueOrDefault(genre, 0) + 1;
    }

    public bool CanPlay(string genre)
    {
        return _recentPlays.GetValueOrDefault(genre, 0) < MinimumGap;
    }

    public void Reset()
    {
        _recentPlays.Clear();
    }
}
