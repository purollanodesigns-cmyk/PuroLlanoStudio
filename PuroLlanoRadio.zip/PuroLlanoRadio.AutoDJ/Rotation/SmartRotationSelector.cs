using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using PuroLlanoRadio.Library.Interfaces;
using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.AutoDJ.Rotation;

public class SmartRotationSelector : ISmartRotationSelector
{
    private readonly ILibraryService _libraryService;
    private readonly LinkedList<Guid> _recentTrackIds = new();
    private readonly LinkedList<string> _recentArtists = new();
    private readonly Random _random = new();

    public SmartRotationSelector(ILibraryService libraryService)
    {
        _libraryService = libraryService;
    }

    public string PreferredGenre { get; set; } = "CUALQUIERA";
    public int ArtistRepeatAvoidance { get; set; } = 3;
    public int HistorySize { get; set; } = 50;

    public async Task<TrackInfo?> SelectNextAsync(
        IReadOnlyCollection<Guid> unavailableTrackIds,
        CancellationToken cancellationToken = default)
    {
        var allTracks = await _libraryService.GetAllTracksAsync()
            .ConfigureAwait(false);

        if (allTracks == null || allTracks.Count == 0)
            return null;

        // Estrategia de selección por niveles. Nunca bloqueamos la automatización
        // solo porque HistorySize/ArtistRepeatAvoidance sean demasiado estrictos.
        var baseCandidates = allTracks
            .Where(track => !unavailableTrackIds.Contains(track.Id))
            .ToList();

        if (baseCandidates.Count == 0)
            return null;

        var candidates = baseCandidates
            .Where(track => !_recentTrackIds.Contains(track.Id))
            .ToList();

        if (candidates.Count == 0)
            candidates = baseCandidates.ToList();

        var artistFiltered = candidates
            .Where(track => !IsRecentlyUsedArtist(track.Artist))
            .ToList();

        if (artistFiltered.Count > 0)
            candidates = artistFiltered;

        if (!string.IsNullOrWhiteSpace(PreferredGenre) &&
            !PreferredGenre.Equals("CUALQUIERA", StringComparison.OrdinalIgnoreCase))
        {
            var genreCandidates = candidates
                .Where(track => string.Equals(
                    track.Genre,
                    PreferredGenre,
                    StringComparison.OrdinalIgnoreCase))
                .ToList();

            // El género es preferencia, no un bloqueo duro.
            if (genreCandidates.Count > 0)
                candidates = genreCandidates;
        }

        if (candidates.Count == 0)
            candidates = baseCandidates.ToList();

        var selected = candidates[_random.Next(candidates.Count)];


        RegisterPlayed(selected);


        return selected;
    }


    public void RegisterPlayed(TrackInfo track)
    {
        ArgumentNullException.ThrowIfNull(track);


        _recentTrackIds.Remove(track.Id);


        if (!string.IsNullOrWhiteSpace(track.Artist))
        {
            var currentNode = _recentArtists.First;
            while (currentNode != null)
            {
                if (string.Equals(currentNode.Value, track.Artist,
                    StringComparison.OrdinalIgnoreCase))
                {
                    _recentArtists.Remove(currentNode);
                    break;
                }
                currentNode = currentNode.Next;
            }
        }


        _recentTrackIds.AddFirst(track.Id);
        _recentArtists.AddFirst(track.Artist ?? string.Empty);


        while (_recentTrackIds.Count > Math.Max(1, HistorySize))
            _recentTrackIds.RemoveLast();


        var artistHistorySize =
            Math.Max(1, Math.Max(HistorySize, ArtistRepeatAvoidance + 1));


        while (_recentArtists.Count > artistHistorySize)
            _recentArtists.RemoveLast();
    }


    public void ClearHistory()
    {
        _recentTrackIds.Clear();
        _recentArtists.Clear();
    }


    private bool IsRecentlyUsedArtist(string? artist)
    {
        if (ArtistRepeatAvoidance <= 0)
            return false;


        if (string.IsNullOrWhiteSpace(artist))
            return false;


        return _recentArtists
            .Take(Math.Min(
                ArtistRepeatAvoidance,
                _recentArtists.Count))
            .Any(existing =>
                string.Equals(
                    existing,
                    artist,
                    StringComparison.OrdinalIgnoreCase));
    }
}