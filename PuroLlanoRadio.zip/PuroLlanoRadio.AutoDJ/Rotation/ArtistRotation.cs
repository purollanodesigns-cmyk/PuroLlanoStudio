﻿public class ArtistRotation
{
    private readonly Dictionary<string, DateTime> _lastPlayed = new();

    public int MinimumGap { get; set; } = 3;

    public void RegisterPlay(string artist)
    {
        _lastPlayed[artist] = DateTime.UtcNow;
    }

    public bool CanPlay(string artist)
    {
        if (!_lastPlayed.ContainsKey(artist))
            return true;

        return (DateTime.UtcNow - _lastPlayed[artist]).TotalMinutes >= MinimumGap;
    }
}
