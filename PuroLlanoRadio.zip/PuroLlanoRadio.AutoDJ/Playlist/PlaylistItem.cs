﻿using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.AutoDJ.Playlist;

public class PlaylistItem
{
    public Guid Id { get; set; }

    public TrackInfo? Track { get; set; }

    public PlaylistType Type { get; set; } = PlaylistType.Song;

    public string Title { get; set; } = "";

    public DateTime ScheduledTime { get; set; }

    public int DurationSeconds { get; set; }

    public TimeSpan Duration { get; set; }
}
