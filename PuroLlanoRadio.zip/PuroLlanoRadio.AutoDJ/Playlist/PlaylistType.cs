﻿namespace PuroLlanoRadio.AutoDJ.Playlist;

public enum PlaylistType
{
    Song,
    Jingle,
    Commercial,
    VoiceSong,
    News,
    Effect,
    Live
}
