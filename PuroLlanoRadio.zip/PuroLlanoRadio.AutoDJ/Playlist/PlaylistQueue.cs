namespace PuroLlanoRadio.AutoDJ.Playlist;

public class PlaylistQueue
{
    private readonly List<PlaylistItem> _items = new();

    public int Count => _items.Count;

    public PlaylistItem? Current { get; private set; }

    public void Enqueue(PlaylistItem item)
    {
        _items.Add(item);
    }

    public PlaylistItem? Dequeue()
    {
        if (_items.Count == 0)
            return null;

        Current = _items[0];
        _items.RemoveAt(0);
        return Current;
    }

    public IReadOnlyList<PlaylistItem> GetItems()
    {
        return _items.AsReadOnly();
    }

    public PlaylistItem? Peek()
    {
        return _items.Count > 0 ? _items[0] : null;
    }

    public bool RemoveAt(int index)
    {
        if (index < 0 || index >= _items.Count) return false;
        _items.RemoveAt(index);
        return true;
    }

    public bool Remove(PlaylistItem item)
    {
        return _items.Remove(item);
    }

    public bool MoveUp(int index)
    {
        if (index <= 0 || index >= _items.Count) return false;
        (_items[index], _items[index - 1]) = (_items[index - 1], _items[index]);
        return true;
    }

    public bool MoveDown(int index)
    {
        if (index < 0 || index >= _items.Count - 1) return false;
        (_items[index], _items[index + 1]) = (_items[index + 1], _items[index]);
        return true;
    }

    public void Clear()
    {
        _items.Clear();
    }
}
