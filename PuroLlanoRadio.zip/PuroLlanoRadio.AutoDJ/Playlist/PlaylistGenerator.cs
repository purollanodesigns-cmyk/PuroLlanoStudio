﻿using PuroLlanoRadio.AutoDJ.Interfaces;
using PuroLlanoRadio.Library.Models;

namespace PuroLlanoRadio.AutoDJ.Playlist;

public class PlaylistGenerator : IPlaylistGenerator
{
    private readonly PlaylistQueue _queue = new();

    public async Task<List<PlaylistItem>> GenerateAsync(int count)
    {
        var result = new List<PlaylistItem>();

        for (int i = 0; i < count; i++)
        {
            var item = await GetNextAsync();
            if (item != null)
                result.Add(item);
        }

        return result;
    }

    public Task<PlaylistItem?> GetNextAsync()
    {
        return Task.FromResult<PlaylistItem?>(null);
    }
}
